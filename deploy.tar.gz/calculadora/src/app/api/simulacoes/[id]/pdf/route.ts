import { NextResponse } from "next/server";
import { PDFDocument, StandardFonts, rgb } from "pdf-lib";
import { TipoAuditoria } from "@prisma/client";
import { prisma } from "@/lib/prisma";

const money = (value: number) => new Intl.NumberFormat("pt-BR", { style: "currency", currency: "BRL" }).format(value);
const date = (value: Date) => new Intl.DateTimeFormat("pt-BR").format(value);

export async function POST(_: Request, { params }: { params: Promise<{ id: string }> }) {
  const { id } = await params;
  const s = await prisma.simulacao.findUnique({ where: { id } });
  if (!s) return NextResponse.json({ error: "Simulação não encontrada" }, { status: 404 });

  const pdf = await PDFDocument.create();
  pdf.setTitle(`CIFRA - Simulação ${s.id}`);
  pdf.setAuthor("CIFRA Consultoria Tributária");
  const regular = await pdf.embedFont(StandardFonts.Helvetica);
  const bold = await pdf.embedFont(StandardFonts.HelveticaBold);
  const page = pdf.addPage([595.28, 841.89]);
  
  const pine = rgb(0.06, 0.19, 0.15);
  const olive = rgb(0.39, 0.48, 0.27);
  const gray = rgb(0.35, 0.38, 0.37);
  const lightGray = rgb(0.95, 0.96, 0.95);
  const white = rgb(1, 1, 1);
  
  let y = 792;
  const line = (label: string, value: string, strong = false) => {
    page.drawText(label, { x: 50, y, size: 9, font: regular, color: gray });
    page.drawText(value, { x: 300, y, size: 9, font: strong ? bold : regular, color: pine });
    y -= 18;
  };
  const section = (title: string) => { 
    y -= 5; 
    page.drawText(title.toUpperCase(), { x: 50, y, size: 10, font: bold, color: olive }); 
    y -= 20; 
  };

  // CABEÇALHO
  page.drawText("CIFRA", { x: 50, y, size: 19, font: bold, color: olive });
  page.drawText("Relatório de Simulação de INSS de Obra", { x: 50, y: y - 25, size: 16, font: bold, color: pine });
  const codigo = `CIFRA-${s.createdAt.getFullYear()}-${s.id.slice(-6).toUpperCase()}`;
  page.drawText(`Código ${codigo} | versão ${s.versao} | Emitido em ${date(new Date())}`, { x: 50, y: y - 45, size: 9, font: regular, color: gray });
  
  y -= 80;

  // RESUMO EXECUTIVO
  const percentual = s.inssDevido > 0 ? ((s.economiaImposto / s.inssDevido) * 100).toFixed(0) : "0";
  page.drawText(`Redução estimada de ${percentual}% no INSS da obra`, { x: 50, y, size: 13, font: bold, color: pine });
  y -= 25;

  // Quadro de Resumo (Cards)
  page.drawRectangle({ x: 50, y: y - 40, width: 115, height: 45, color: lightGray });
  page.drawText("Cenário Padrão", { x: 55, y: y - 15, size: 8, font: regular, color: gray });
  page.drawText(money(s.inssDevido), { x: 55, y: y - 30, size: 10.5, font: bold, color: pine });

  page.drawRectangle({ x: 175, y: y - 40, width: 115, height: 45, color: lightGray });
  page.drawText("Com Planejamento", { x: 180, y: y - 15, size: 8, font: regular, color: gray });
  page.drawText(money(s.inssComReducao), { x: 180, y: y - 30, size: 10.5, font: bold, color: pine });

  page.drawRectangle({ x: 300, y: y - 40, width: 115, height: 45, color: lightGray });
  page.drawText("Economia Tributária", { x: 305, y: y - 15, size: 8, font: regular, color: gray });
  page.drawText(money(s.economiaImposto), { x: 305, y: y - 30, size: 10.5, font: bold, color: pine });

  page.drawRectangle({ x: 425, y: y - 40, width: 120, height: 45, color: olive });
  page.drawText("Economia Líquida", { x: 430, y: y - 15, size: 8, font: bold, color: white });
  page.drawText(money(s.economiaLiquida), { x: 430, y: y - 30, size: 11.5, font: bold, color: white });

  y -= 75;

  section("Identificação do cliente e da obra");
  line("Cliente", s.nomeCliente, true); 
  line("Contato", [s.telefone, s.email].filter(Boolean).join(" | ") || "Não informado");
  line("Obra", `${s.tipoObra} - ${s.uf} - ${s.responsavel}`); 
  line("Período", `${date(s.dataInicio)} a ${date(s.dataFim)}`);
  
  section("Dados utilizados no cálculo");
  line("Área de construção", `${s.areaConstrucao.toFixed(2)} m2`); 
  line("Área de reforma", `${s.areaReforma.toFixed(2)} m2`);
  line("Área de demolição", `${s.areaDemolicao.toFixed(2)} m2`); 
  line("Área de piscina", `${s.areaPiscina.toFixed(2)} m2`);
  line("VAU utilizado", `${money(s.vauUsado)} / m2`); 
  line("Competência VAU", s.competenciaVau || "Não informada");

  section("Detalhamento tributário e resultado");
  line("Custo total estimado da obra", money(s.codTotal)); 
  line("Remuneração de mão de obra estimada", money(s.rmtTotal));
  line("INSS estimado sem planejamento", money(s.inssDevido), true); 
  line("INSS estimado após planejamento", money(s.inssComReducao), true);
  
  const mesesRetro = Math.max(0, (s.createdAt.getFullYear() - s.dataInicio.getFullYear()) * 12 + (s.createdAt.getMonth() - s.dataInicio.getMonth()));
  const multaMaed = s.podeFatorAjuste ? mesesRetro * 100 : 0;
  if (multaMaed > 0) {
    line("Multa MAED (Atraso DCTFWeb)", money(multaMaed));
  }

  line("Economia tributária estimada", money(s.economiaImposto)); 
  line("Honorários da consultoria", money(s.honorarios)); 
  line("Economia líquida estimada do cliente", money(s.economiaLiquida), true);
  
  y -= 5;
  section("Premissas e Observações");
  page.drawText("Esta simulação é válida por 15 dias e está sujeita à conferência documental, validação das", { x: 50, y, size: 8.5, font: regular, color: gray });
  y -= 12;
  page.drawText("características da obra e atualização dos parâmetros legais aplicáveis.", { x: 50, y, size: 8.5, font: regular, color: gray });
  y -= 10;
  page.drawText("Estimativa interna. Confira os dados e o cálculo definitivo no SERO/e-CAC antes do recolhimento.", { x: 50, y, size: 8.5, font: regular, color: gray });

  // RODAPÉ
  y = 70;
  page.drawLine({ start: { x: 50, y }, end: { x: 545, y }, thickness: 1, color: lightGray });
  y -= 15;
  page.drawText("Glossário: VAU (Valor Atualizado Unitário) | RMT (Remuneração da mão de obra) | SERO (Serviço de Aferição)", { x: 50, y, size: 7, font: regular, color: gray });
  y -= 15;
  page.drawText("CIFRA Consultoria Tributária Ltda | CNPJ: 45.123.456/0001-99", { x: 50, y, size: 8, font: bold, color: olive });
  y -= 12;
  page.drawText("contato@cifrainssdeobras.com.br | www.cifrainssdeobras.com.br", { x: 50, y, size: 8, font: regular, color: gray });
  page.drawText("Página 1 de 1", { x: 500, y, size: 8, font: regular, color: gray });

  const bytes = await pdf.save();
  await prisma.auditoria.create({ data: { simulacaoId: id, tipo: TipoAuditoria.RELATORIO_EMITIDO, usuario: s.criadoPor, detalhes: "Relatório PDF emitido (Formato Comercial)" } });
  
  return new NextResponse(Buffer.from(bytes), { 
    headers: { 
      "Content-Type": "application/pdf", 
      "Content-Disposition": `attachment; filename="${codigo}.pdf"`, 
      "Cache-Control": "no-store" 
    } 
  });
}
