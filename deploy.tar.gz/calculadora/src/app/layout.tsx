import type { Metadata } from "next";
import { Manrope, Oswald } from "next/font/google";
import { AppHeader } from "@/components/layout/app-header";
import "./globals.css";

const manrope = Manrope({
  subsets: ["latin"],
  variable: "--font-manrope",
  display: "swap",
});

const display = Oswald({
  subsets: ["latin"],
  weight: ["400", "500"],
  variable: "--font-display",
  display: "swap",
});

export const metadata: Metadata = {
  title: "Simulador INSS de Obra — CIFRA",
  description: "Sistema interno de planejamento tributário de obra da CIFRA.",
  robots: { index: false, follow: false },
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="pt-BR" className={`${manrope.variable} ${display.variable} h-full antialiased`}>
      <body className="min-h-full bg-paper">
        <div
          aria-hidden
          className="pointer-events-none fixed inset-0 opacity-60 z-[-1]"
          style={{
            background:
              "radial-gradient(60rem 30rem at 15% -10%, rgba(124,138,104,.16), transparent 60%), radial-gradient(50rem 25rem at 100% 0%, rgba(201,154,46,.10), transparent 60%)",
          }}
        />
        <a
          href="#conteudo"
          className="sr-only focus:not-sr-only focus:fixed focus:top-2 focus:left-2 focus:z-[60] focus:rounded-lg focus:bg-pine-800 focus:px-4 focus:py-2 focus:text-paper"
        >
          Pular para o conteúdo
        </a>

        <AppHeader />
        <main id="conteudo">{children}</main>
      </body>
    </html>
  );
}
