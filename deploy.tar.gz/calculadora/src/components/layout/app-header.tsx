"use client";

import * as React from "react";
import Link from "next/link";
import { usePathname } from "next/navigation";
import { Calculator, History, SlidersHorizontal, LogOut } from "lucide-react";
import { motion } from "framer-motion";
import { sair } from "@/app/login/actions";

export function AppHeader() {
  const pathname = usePathname();
  
  if (pathname === "/login") return null;

  return (
    <header className="sticky top-0 z-50 flex h-16 w-full items-center gap-3 border-b border-graphite-200 bg-white/80 px-6 backdrop-blur-md">
      <div className="relative rounded-lg bg-gradient-to-br from-paper to-sage-100 px-3 py-1.5 leading-none text-pine-950 shadow-lg shadow-black/20">
        <span className="block text-sm font-black tracking-wider">CIFRA</span>
        <small className="block text-[7px] font-semibold tracking-[3px] text-graphite-500 uppercase">
          Ops
        </small>
      </div>
      
      <div className="h-6 w-px bg-graphite-200 ml-1" />
      
      <div className="hidden items-center gap-2 text-xs font-medium text-graphite-500 sm:flex ml-2">
        <Calculator className="size-3.5 text-olive-500" />
        Sistema de Planejamento Tributário
      </div>

      <div className="ml-auto flex items-center gap-1">
        <TabLink href="/" icon={SlidersHorizontal} active={pathname === "/"}>
          Simulação
        </TabLink>
        <TabLink href="/simulacoes" icon={History} active={pathname.startsWith("/simulacoes")}>
          Histórico
        </TabLink>
      </div>

      <div className="ml-2 hidden items-center gap-1.5 rounded-full border border-graphite-200 bg-graphite-100 px-3 py-1 text-[11px] font-semibold text-pine-600 sm:flex">
        <span className="size-1.5 rounded-full bg-sage-400 shadow-[0_0_8px_2px_rgba(170,181,152,0.6)]" />
        Uso interno
      </div>
      
      <form action={sair}>
        <button className="ml-2 flex items-center justify-center rounded-full border border-graphite-200 p-2 text-graphite-500 hover:bg-graphite-200 hover:text-graphite-900 transition-colors" title="Sair">
          <LogOut className="size-4" />
        </button>
      </form>
    </header>
  );
}

function TabLink({ href, active, icon: Icon, children }: { href: string; active: boolean; icon: any; children: React.ReactNode }) {
  return (
    <Link
      href={href}
      className={`relative flex items-center gap-1.5 rounded-full px-3.5 py-1.5 text-xs font-semibold transition-colors ${
        active ? "text-pine-950" : "text-graphite-500 hover:text-graphite-900"
      }`}
    >
      {active && (
        <motion.span
          layoutId="tab-pill-header"
          className="absolute inset-0 rounded-full bg-gradient-to-br from-paper to-sage-100 shadow"
          transition={{ type: "spring", bounce: 0.2, duration: 0.4 }}
        />
      )}
      <Icon className="relative z-10 size-3.5" />
      <span className="relative z-10">{children}</span>
    </Link>
  );
}
