export function PdfButton({ id }: { id: string }) {
  const basePath = process.env.NEXT_PUBLIC_BASE_PATH ?? "";
  return <form method="post" action={`${basePath}/api/simulacoes/${id}/pdf`}>
    <button className="rounded-lg bg-olive-500 px-4 py-2 text-sm font-bold text-white hover:bg-olive-400">Baixar PDF</button>
  </form>;
}
